Demo ALiCE Onboarding [Insomnia Workspace]
==========================================

This workspace could be useful to help you to understand ALiCE Onboarding API.

Getting Started
---------------

1. Import the Workspace in the Insomnia. Import/Export -> Import Data -> From File 
    - Use DemoAliceOnboarding.json (Insomnia v4 - JSON)
2. Activate just installed Workspace Demo ALiCE Onboarding.
3. Configure your API TOKEN. Manage Environments -> Base Environment -> apikey_client

Fill it with your API KEY

```json
{
  "apikey_client": "<ADD-HERE-APIKEY-CLIENT>"
}
``` 

For more info about the services, please check following links:

* Onboarding: https://apis.alicebiometrics.com/onboarding/ui/#/
